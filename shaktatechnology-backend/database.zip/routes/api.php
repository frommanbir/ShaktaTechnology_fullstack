<?php

use App\Http\Controllers\API\CareerController;
use App\Http\Controllers\API\CareerTypeController;
use App\Http\Controllers\API\FaqController;
use App\Http\Controllers\API\MemberController;
use App\Http\Controllers\API\ProjectController;
use App\Http\Controllers\API\ServiceController;
use App\Http\Controllers\API\AuthController;
use App\Http\Controllers\API\ContactController;
use App\Http\Controllers\API\SettingController;
use App\Http\Controllers\API\GalleryController;
use App\Http\Controllers\API\NewsController;
use App\Http\Controllers\TestimonialController;
use App\Http\Controllers\API\VisitController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

// Authentication routes
Route::post('/login', [AuthController::class, 'login']);

// Public routes (no authentication required)
Route::post('/track-visit', [VisitController::class, 'track']);
Route::get('/track-visit', [VisitController::class, 'index']);
Route::get('/services', [ServiceController::class, 'index']);
Route::get('/services/{id}', [ServiceController::class, 'show']);

Route::get('/projects', [ProjectController::class, 'index']);
Route::get('/projects/{id}', [ProjectController::class, 'show']);

Route::get('/members', [MemberController::class, 'index']);
Route::get('/members/{id}', [MemberController::class, 'show']);

Route::get('/faqs', [FaqController::class, 'index']);
Route::get('/faqs/{id}', [FaqController::class, 'show']);

Route::get('/careers', [CareerController::class, 'index']);
Route::get('/careers/{id}', [CareerController::class, 'show']);

// Career types are public (needed by the frontend form)
Route::get('/career-types', [CareerTypeController::class, 'index']);

// Public contact form submission only
Route::post('/contacts', [ContactController::class, 'store']);

Route::get('/settings', [SettingController::class, 'index']);
Route::get('/settings/{id}', [SettingController::class, 'show']);

Route::get('/galleries', [GalleryController::class, 'index']);
Route::get('/galleries/{id}', [GalleryController::class, 'show']);

Route::get('/news', [NewsController::class, 'index']);
Route::get('/news/{id}', [NewsController::class, 'show']);

Route::get('/testimonials', [TestimonialController::class, 'index']);
Route::get('/testimonials/{id}', [TestimonialController::class, 'show']);

// Routes protected by Sanctum
Route::middleware('auth:sanctum')->group(function () {
    // Admin registration & logout
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/logout', [AuthController::class, 'logout']);

    // Protected CRUD operations
    Route::apiResource('services', ServiceController::class)->except(['index', 'show']);
    Route::apiResource('projects', ProjectController::class)->except(['index', 'show']);
    Route::apiResource('members', MemberController::class)->except(['index', 'show']);
    Route::patch('/members/{id}/toggle-status', [MemberController::class, 'toggleStatus']);
    Route::apiResource('faqs', FaqController::class)->except(['index', 'show']);
    Route::apiResource('careers', CareerController::class)->except(['index', 'show']);
    Route::patch('/careers/{id}/toggle-status', [CareerController::class, 'toggleStatus']);
    Route::apiResource('career-types', CareerTypeController::class)->except(['index', 'show']);
    Route::apiResource('contacts', ContactController::class)->except(['store']);
    Route::apiResource('settings', SettingController::class)->except(['index', 'show']);
    Route::apiResource('galleries', GalleryController::class)->except(['index', 'show']);
    Route::apiResource('news', NewsController::class)->except(['index', 'show']);
    Route::apiResource('testimonials', TestimonialController::class)->except(['index', 'show']);

    // Authenticated user info
    Route::get('/user', function (Request $request) {
        return $request->user();
    });
});
